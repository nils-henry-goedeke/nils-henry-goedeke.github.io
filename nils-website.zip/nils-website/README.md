# Nils Goedeke – personal website

**Live link (Claude artifact, public):** https://claude.ai/artifact/QcJxr5dM822smTAJRcwdZf
Current version: 1795102353-2426 (19 Nov 2026)

## What's in this folder

| Path | What it is |
|---|---|
| `index.html` | The finished website, one self-contained file (all images embedded). Opens in any browser and can be hosted as-is (e.g. GitHub Pages). |
| `src/template.html` | Base page: layout, About and Path tabs, contact, styles and scripts |
| `src/gen.py` | Project cards and the Certificates tab (all texts live here) |
| `src/extra.css`, `src/extra.js` | Styles and scripts for code viewer, scenario switch, certificates |
| `src/patch.py` | Color palette, font, hero, AI note; inserts the path timeline |
| `src/path_chart.js` | "My path" timeline: all career steps, dates and texts |
| `src/build.py` | Embeds photo and images and writes `index.html` |
| `images/` | Portrait, project screenshots, certificate previews |
| `data/code_all.json` | Code excerpts shown in "View the code" (SQL, ML, bike rentals) |

## Rebuild after changes

```
cd src
python3 gen.py && python3 patch.py && python3 build.py
```
Needs Python 3 with Pillow (`pip install pillow`). Output: `../index.html`.

## Updating with Claude (every 3–4 weeks)

Share this folder with Claude in the Life Audit project and say what changed (new project, certificate, role). Claude edits the source, rebuilds and republishes the same artifact, so the link stays the same.

## Notes

- Reference letters and the SRH transcript are not included on purpose (address, birth date, grades).
- The negotiation certificate preview has the birth date covered.
- New England Revolution: the main client deck is marked CONFIDENTIAL; the site only uses the 4-slide summary deck and the poster.

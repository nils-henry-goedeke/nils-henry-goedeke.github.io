import re
p='template2.html'
s=open(p,encoding='utf-8').read()

# ---- palette: bottle green instead of suit navy ----
cmap={'#13233F':'#173B6C','#1B2F52':'#1F4884','#2A3F63':'#2E5590','#34496D':'#3A619C',
'#40577D':'#4B70A8','#C9D4E3':'#CAD8EC','#F1F4F8':'#F3F5F8'}
for a,b in cmap.items(): s=re.sub(a,b,s,flags=re.I)

# ---- type ----
s=s.replace('family=Archivo:wdth,wght@62..125,100..900','family=Schibsted+Grotesk:ital,wght@0,400..900;1,400..900')
s=s.replace('"Archivo"','"Schibsted Grotesk"')

# ---- shapes: fewer pills and soft cards ----
s=s.replace('border-radius:999px','border-radius:5px')
for r in ['16px','14px','12px']: s=s.replace(f'border-radius:{r}',f'border-radius:6px')
s=s.replace('.proj .tools span{font-size:13.5px;font-weight:500;padding:4px 11px;border-radius:5px;background:#E4EBE6;color:#2E3D34}',
            '.proj .tools span{font-size:14px;font-weight:500;color:var(--steel)}\n.proj .tools span+span::before{content:"/";margin:0 9px 0 1px;color:#BAC9BF}')
s=s.replace('.proj .lead{font-size:16.5px;color:#27342D;max-width:72ch;margin-bottom:24px;padding-left:16px;border-left:3px solid var(--amber)}',
            '.proj .lead{font-size:17px;color:#27342D;max-width:70ch;margin-bottom:26px}')

# ---- hero: light background, framed photo ----
s=s.replace('alt="Nils Goedeke in a navy suit"','alt="Portrait of Nils Goedeke"')
hero_css='''
/* hero v3: light, photo on an offset block */
.hero{background:var(--paper);color:var(--ink);border-bottom:1px solid var(--rule)}
.hero .wrap{grid-template-columns:7fr 5fr;align-items:center;gap:56px;padding-top:72px;padding-bottom:84px}
.hello{color:var(--steel)} .hello b{color:var(--ink)}
.hero .lede{color:#2A3850}
.hero .actions{margin:30px 0 0}
.hero .btn-line{border-color:#B9C5D6;color:var(--ink)} .hero .btn-line:hover{border-color:var(--ink)}
.hero h1{color:var(--suit);font-size:clamp(34px,4.8vw,60px);max-width:16ch}
.portrait{justify-self:center;position:relative;overflow:visible;border-radius:0;max-width:320px;aspect-ratio:auto;margin:0 18px 18px 0}
.portrait::before{content:"";position:absolute;left:22px;top:22px;right:-18px;bottom:-18px;background:var(--suit);border-radius:2px}
.portrait::after{content:"";position:absolute;left:-14px;top:-14px;width:64px;height:64px;border-left:3px solid var(--amber);border-top:3px solid var(--amber)}
.portrait img{position:relative;z-index:1;border-radius:2px;filter:none}
.proj-head{background:#fff;color:var(--ink);border-bottom:1px solid var(--rule)}
.proj-head h1{color:var(--suit)}
.proj-head .lede{color:#2A3850}
.chip{border-color:#B9C5D6;color:var(--ink)}
.chip[aria-pressed="true"]{background:var(--suit);color:#fff;border-color:var(--suit)}
.proj .tools{gap:0}
.proj .tools span{padding:0;background:none;border-radius:0;font-size:14px;color:var(--steel)}
.proj .tools span+span::before{content:"/";margin:0 9px;color:#B9C5D6}
.proj .lead{padding-left:0;border-left:0;font-size:17px;max-width:70ch}
.tab{white-space:nowrap}
@media (max-width:860px){
  .hero .wrap{grid-template-columns:1fr;gap:36px;padding-top:40px;padding-bottom:56px}
  .portrait{justify-self:start;max-width:210px;order:-1;border-radius:0}
  .tab{padding:0 9px;font-size:14px}
}
'''
s=s.replace('</style>',hero_css+'</style>',1)

# ---- skills block, less templated ----
s=s.replace('<h2>What I bring</h2>','<h2>What I work with</h2>')
s=re.sub(r'\s*<p class="why">[^<]*</p>','',s)
s=s.replace('<li>LLM workflows <small>Claude API</small></li>','<li>LLM workflows with Claude</li>')
s=s.replace('<li>Certificates from Google, IBM and Anthropic</li>','<li>Certificates from Google and Anthropic</li>')

# ---- path: dates and tasks from the reference letters ----
s=s.replace('''{t:2019.25,label:"SAP",sub:"2019",kind:"Internship",when:"April 2019",title:"SAP, Walldorf",
   text:"Three weeks in SAP’s marketing and sales organization, before I had even started university.",''',
'''{t:2019.45,label:"SAP",sub:"2019",kind:"Internship",when:"June 2019",title:"School internship, SAP, Walldorf",
   text:"A week with SAP’s marketing team for Germany, two years before university: preparing events, building PowerPoint decks and sitting in on team meetings and calls.",''')
s=s.replace('''{t:2023.85,label:"Roche",sub:"2023–24",kind:"Internship",when:"November 2023 – April 2024",title:"Marketing & Sales Intern, Roche Diagnostics",
   text:"Six months in point-of-care diagnostics: market and competitor analyses, sales reports, CRM data and customer events. I left with the highest possible performance rating.",''',
'''{t:2023.83,label:"Roche",sub:"2023–24",kind:"Internship",when:"October 2023 – April 2024",title:"Marketing Intern, Point of Care, Roche Diagnostics",
   text:"Six months in Mannheim supporting product management for point-of-care diagnostics: tenders, campaigns and marketing material, KPI dashboards maintained with external agencies, Excel analyses, market research and process maps in Lucidchart. My reference letter gives the top rating.",''')
s=s.replace('''{t:2025.1,label:"11teamsports",sub:"2025",kind:"Internship",when:"February – July 2025",title:"Marketplace Analyst, 11teamsports",
   text:"Two of us ran the marketplace business, selling surplus stock on Amazon, Zalando and About You, worth about €15,000 to €20,000 a day. I built the daily sales, order and stock reporting in Excel, Power BI and AWS.",''',
'''{t:2025.2,label:"11teamsports",sub:"2025",kind:"Internship",when:"March – August 2025",title:"Customer Operations & Marketplace, 11teamsports",
   text:"I started in customer operations for football clubs, then moved to the marketplace team. Two of us ran the business of selling surplus stock on Amazon, Zalando, Otto and About You, worth about €15,000 to €20,000 a day: daily data monitoring, product mapping, fixing listings, Amazon FBA shipments and top-seller analyses. Top rating in my reference letter.",''')

# ---- path tab: timeline with lanes ----
pj=open('path_chart.js',encoding='utf-8').read()
a=s.index('/* ---------- path chart ---------- */'); b=s.index('/* ---------- projects ---------- */')
s=s[:a]+pj+'\n'+s[b:]
s=s.replace('<p class="learn" id="d-learn"></p>','<p class="picked" id="d-tools"></p>\n          <p class="learn" id="d-learn"></p>')
s=s.replace('<h1>My path, plotted</h1>','<h1>My path so far</h1>')
s=s.replace('<p class="lede">Every step on this line taught me something I still use. Click a point, or use the buttons, to walk through it.</p>',
 '<p class="lede">Study, work and student roles on one timeline: how long each step took, where they overlapped and what I picked up along the way. Click a bar, or use the buttons below.</p>')
chart_css='''
/* path timeline */
.chart{overflow-x:auto;padding-bottom:6px}
.chart svg{min-width:760px}
.lane-lbl{fill:var(--mist);font-size:13px;font-weight:600}
.lane-rule{stroke:#2E5590;stroke-width:1}
.yr-grid{stroke:#2E5590;stroke-width:1;stroke-dasharray:2 5}
.today{stroke:#fff;stroke-width:1.5;stroke-dasharray:3 4;opacity:.8}
.today-lbl{fill:#fff;font-size:12px;font-weight:600}
.pt .bar-r{stroke-width:2;transition:stroke .15s}
.pt.lane0 .bar-r{fill:var(--amber);stroke:var(--amber)}
.pt.lane1 .bar-r{fill:#DCE7F5;stroke:#DCE7F5}
.pt.lane2 .bar-r{fill:transparent;stroke:var(--amber)}
.pt.nx .bar-r{fill:transparent;stroke:#fff;stroke-dasharray:5 5}
.pt text{font-size:13px;font-weight:600}
.pt text.in{fill:var(--suit)}
.pt.lane2 text.in,.pt.nx text.in{fill:#fff}
.pt text.out{fill:#DCE5F1}
.pt.on .bar-r{stroke:#fff;stroke-width:3}
.pt.lane1.on .bar-r,.pt.lane0.on .bar-r{stroke:#fff}
.pt:hover .bar-r,.pt:focus-visible .bar-r{stroke:#fff}
.detail .picked{margin-top:10px;color:#DCE5F1}
.detail .picked b{color:var(--amber);font-weight:600}
.ai-note{margin-top:26px;max-width:72ch;font-size:14.5px;color:var(--mist);line-height:1.55}
.ai-note b{color:#fff;font-weight:600}
'''
s=s.replace('</style>',chart_css+'</style>',1)
s=s.replace('<div class="foot"><span>Nils Goedeke, Boston, MA</span>',
 '<p class="ai-note"><b>How this site was made.</b> I built it together with Claude, Anthropic’s AI model. I decided what goes on it, supplied the projects, files and numbers and checked every figure against my own work; Claude helped with the design, the code and polishing my English. Using AI this way is part of how I work.</p>\n    <div class="foot"><span>Nils Goedeke, Boston, MA</span>')
s=s.replace('<li>Certificates from Google and Anthropic</li>','<li>Certificates from Google and Anthropic</li>\n            <li>Built this website with Claude</li>')

open(p.replace('template2','template3'),'w',encoding='utf-8').write(s)
left=[c for c in re.findall(r'#[0-9A-Fa-f]{6}',s) if c.upper() in [k.upper() for k in cmap]]
print('done', 'unmapped left:',left[:5], 'what I bring' in s)

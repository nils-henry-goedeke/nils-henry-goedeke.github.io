import re,base64,os
from PIL import Image
s=open('template3.html',encoding='utf-8').read()
def b64(p): return base64.b64encode(open(p,'rb').read()).decode()
s=s.replace('__PHOTO__',b64('../images/photo.jpg'))
for k in sorted(set(re.findall(r'__IMG_(\w+?)__',s))):
    p=f'../images/certificates/{k[2:]}.jpg' if k.startswith('c_') else f'../images/projects/p_{k}.jpg'
    s=s.replace(f'__IMG_{k}__','data:image/jpeg;base64,'+b64(p))
assert '__' not in re.sub(r'__[a-z]+__','',s) or True
print('left placeholders:',re.findall(r'__[A-Z_a-z0-9]+__',s)[:5])
os.makedirs('out',exist_ok=True)
open('../index.html','w',encoding='utf-8').write(s); print(len(s)//1024,'KB')

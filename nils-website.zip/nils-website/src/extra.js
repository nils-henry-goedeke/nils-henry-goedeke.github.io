/* ---------- scenario switch (11teamsports model, FY2027, EUR) ---------- */
const scnData=[
  {n:"Base case",rev:4745000,cm:823252,cmr:.173,oi:661437,note:"The budget as planned: €4.75M net revenue and a healthy operating income."},
  {n:"Volume −20%",rev:3796000,cm:658602,cmr:.173,oi:496787,note:"20% fewer units sold. The margin per unit stays intact, so operating income falls by about a quarter and the unit stays clearly profitable."},
  {n:"Price −20%",rev:3796000,cm:64052,cmr:.017,oi:-97763,note:"Same revenue as the volume scenario, but through deeper discounts. Costs per unit don’t fall with the price, the margin almost disappears and the unit makes a loss. That’s why the price floor matters."},
  {n:"Volume +10%",rev:5219500,cm:905578,cmr:.173,oi:743763,note:"10% more units. Upside is limited, because volume is capped by how much surplus stock exists."}
];
document.querySelectorAll("[data-scn]").forEach(box=>{
  const eur=v=>(v<0?"−":"")+"€"+Math.abs(Math.round(v/1000)).toLocaleString("en-US")+"k";
  const bars=box.querySelector(".scn-bars");
  const max=Math.max(...scnData.map(s=>Math.abs(s.oi))), negMax=100000, span=max+negMax;
  const zeroPct=negMax/span*100;
  scnData.forEach((s,i)=>{
    const r=document.createElement("div"); r.className="scn-bar";
    const w=Math.abs(s.oi)/span*100;
    const left=s.oi<0?zeroPct-w:zeroPct;
    r.innerHTML=`<span>${s.n}</span><span class="track"><span class="fill${s.oi<0?" neg":""}" style="left:${left}%;width:${w}%"></span><span class="zero" style="left:${zeroPct}%"></span></span>`;
    bars.appendChild(r);
  });
  const lab=document.createElement("p"); lab.className="scn-bar"; lab.style.marginTop="2px";
  lab.innerHTML="<span></span><span>Operating income by scenario</span>"; bars.appendChild(lab);
  const set=i=>{
    const s=scnData[i];
    box.querySelectorAll(".scn-btns button").forEach((b,k)=>b.setAttribute("aria-pressed",k===i?"true":"false"));
    box.querySelector('[data-k="rev"]').textContent=eur(s.rev);
    box.querySelector('[data-k="cm"]').textContent=eur(s.cm);
    box.querySelector('[data-k="cmr"]').textContent=(s.cmr*100).toFixed(1)+"%";
    const oi=box.querySelector('[data-k="oi"]'); oi.textContent=eur(s.oi); oi.classList.toggle("neg",s.oi<0);
    bars.querySelectorAll("div.scn-bar").forEach((b,k)=>b.classList.toggle("on",k===i));
    box.querySelector(".scn-note").textContent=s.note;
  };
  box.querySelectorAll(".scn-btns button").forEach((b,i)=>b.addEventListener("click",()=>set(i)));
  set(0);
});

/* ---------- copy code ---------- */
document.querySelectorAll(".ccopy").forEach(b=>{
  b.addEventListener("click",async()=>{
    const txt=document.getElementById(b.dataset.copyfrom).textContent;
    try{await navigator.clipboard.writeText(txt);b.textContent="Copied";}
    catch(e){b.textContent="Select the code to copy";}
    setTimeout(()=>{b.textContent="Copy code"},2000);
  });
});

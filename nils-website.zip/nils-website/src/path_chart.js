/* ---------- path chart ---------- */
const steps=[
  {lane:0,s:2019.46,e:2019.48,label:"SAP",kind:"School internship",when:"June 2019",title:"School internship, SAP, Walldorf",
   text:"A week with SAP’s marketing team for Germany, two years before university: preparing events, building PowerPoint decks and sitting in on team meetings and calls.",
   tools:"PowerPoint, event planning",
   learn:"What working in a global company actually looks like from the inside."},
  {lane:1,s:2021.25,e:2024.87,label:"B.A. Business Administration, SRH Heidelberg",kind:"Bachelor’s",when:"April 2021 – November 2024",title:"B.A. Business Administration, SRH University Heidelberg",
   text:"Business degree with a specialization in marketing management, including a six-month internship. I wrote my thesis on corporate branding as a long-term strategy (grade 1.4).",
   tools:"Accounting, applied statistics, investment and financing, strategic management",
   learn:"The fundamentals, and that I kept drifting toward the numbers."},
  {lane:0,s:2023.83,e:2024.33,label:"Roche",kind:"Internship",when:"October 2023 – April 2024",title:"Marketing Intern, Point of Care, Roche Diagnostics",
   text:"Six months in Mannheim supporting product management for point-of-care diagnostics: tenders, campaigns and marketing material, KPI dashboards maintained with external agencies, Excel analyses, market research and process maps in Lucidchart. My reference letter gives the top rating.",
   tools:"Excel, KPI dashboards, Lucidchart, market research",
   learn:"How sales strategy is built inside a large, regulated company."},
  {lane:0,s:2025.21,e:2025.62,label:"11teamsports",kind:"Internship",when:"March – August 2025",title:"Customer Operations & Marketplace, 11teamsports",
   text:"I started in customer operations for football clubs, then moved to the marketplace team. Two of us ran the business of selling surplus stock on Amazon, Zalando, Otto and About You, worth about €15,000 to €20,000 a day: daily data monitoring, product mapping, fixing listings, Amazon FBA shipments and top-seller analyses. Top rating in my reference letter.",
   tools:"Excel, Power BI, AWS, Amazon FBA",
   learn:"That data work is what I want to do."},
  {lane:1,s:2025.67,e:2026.62,label:"Hult MiM",kind:"Master’s",when:"September 2025 – August 2026",title:"Master in Management, Business Analytics, Hult",
   text:"A STEM-designated program in Boston: Python, data management and SQL, business intelligence, machine learning and AI, plus a real consulting project for the New England Revolution. Graduated with a 3.42 GPA.",
   tools:"Python, SQL, Power BI and DAX, Tableau, machine learning, generative AI",
   learn:"The technical toolkit to answer questions with data."},
  {lane:1,s:2026.67,e:2027.28,label:"Hult MFin",kind:"Master’s",when:"September 2026 – April 2027",title:"Master of Finance, Hult",
   text:"Financial accounting, cost and managerial accounting, valuation, FinTech and portfolio analysis.",
   tools:"Financial modeling, valuation, NPV and scenario analysis, portfolio analytics",
   learn:"Which questions in finance are worth asking."},
  {lane:2,s:2026.78,e:2027.28,label:"Treasurer & class rep",kind:"Student leadership",when:"October 2026 – today",title:"Treasurer, Hult Student Association, and class representative",
   text:"Elected class representative of my Master of Finance cohort in October 2026 and Treasurer of the Hult Student Association in November 2026. I look after the association’s budget and speak for my cohort.",
   tools:"Budgeting, stakeholder management",
   learn:"What changes when the numbers belong to other people."},
];
const next={lane:0,s:2027.36,e:2028.2,label:"Your team?",kind:"Next",when:"From May 2027",title:"An analyst role in the US",
  text:"Financial Analyst, FP&A or Data Analyst, anywhere in the US. Available from May 2027 on STEM OPT, no sponsorship needed to start.",
  tools:"Everything above",
  learn:"If this sounds like your team, I’d love to hear from you."};
const all=[...steps,next];
let drawn=false,pts=[],cur=steps.length-2;
const TODAY=2026.89;

function drawChart(){
  if(drawn) return; drawn=true;
  const W=1060,padL=92,padR=10,padT=40,laneH=58,barH=30,H=padT+3*laneH+36;
  // compressed years before university, normal after
  const knots=[[2019,0],[2020,.55],[2021,.9],[2022,1.9],[2023,2.9],[2024,3.9],[2025,4.9],[2026,5.9],[2027,6.9],[2028.3,8.2]];
  const span=knots[knots.length-1][1];
  const u=t=>{for(let i=1;i<knots.length;i++){const[a,ua]=knots[i-1],[b,ub]=knots[i];if(t<=b)return ua+(t-a)/(b-a)*(ub-ua);}return span};
  const x=t=>padL+u(t)/span*(W-padL-padR);
  const NS="http://www.w3.org/2000/svg";
  const svg=document.createElementNS(NS,"svg");
  svg.setAttribute("viewBox",`0 0 ${W} ${H}`);
  svg.setAttribute("aria-label","Timeline from 2019 to 2027 with study, work and student leadership as bars");
  const el=(n,a,p)=>{const e=document.createElementNS(NS,n);for(const k in a)e.setAttribute(k,a[k]);(p||svg).appendChild(e);return e};
  const lanes=["Work","Study","Roles"];
  lanes.forEach((l,i)=>{
    const y=padT+i*laneH;
    el("line",{x1:padL,x2:W-padR,y1:y+laneH-6,y2:y+laneH-6,class:"lane-rule"});
    const t=el("text",{x:0,y:y+barH/2+5,class:"lane-lbl"});t.textContent=l;
  });
  const axY=padT+3*laneH+4;
  for(let yr=2019;yr<=2028;yr++){
    el("line",{x1:x(yr),x2:x(yr),y1:padT-8,y2:axY-8,class:"yr-grid"});
    const tx=el("text",{x:x(yr),y:axY+14,"text-anchor":"middle",class:"tick"});tx.textContent=yr;
  }
  // today marker
  el("line",{x1:x(TODAY),x2:x(TODAY),y1:padT-22,y2:axY-8,class:"today"});
  const td=el("text",{x:x(TODAY),y:padT-27,"text-anchor":"middle",class:"today-lbl"});td.textContent="Today";
  document.getElementById("chart").appendChild(svg);
  all.forEach((s,i)=>{
    const g=el("g",{class:"pt lane"+s.lane+(s===next?" nx":""),tabindex:0,role:"button","aria-label":`${s.when}: ${s.title}`});
    g.style.setProperty("--d",(0.15+i*0.12)+"s");
    const y=padT+s.lane*laneH, x0=x(s.s), w=Math.max(x(s.e)-x0,9);
    el("rect",{x:x0,y,width:w,height:barH,rx:3,class:"bar-r"},g);
    const need=s.label.length*7.3+18, inside=w>=need;
    const toLeft=!inside&&(x0+w+8+need>W);
    const t=el("text",{x:inside?x0+10:(toLeft?x0-8:x0+w+8),y:y+barH/2+5,class:inside?"in":"out","text-anchor":toLeft?"end":"start"},g);
    t.textContent=s.label;
    g.addEventListener("click",()=>show(i));
    g.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();show(i)}});
    pts.push(g);
  });
  show(cur);
}
function show(i){
  cur=(i+all.length)%all.length;
  pts.forEach((p,k)=>p.classList.toggle("on",k===cur));
  const s=all[cur];
  d_when.textContent=s.when; d_kind.textContent=s.kind; d_title.textContent=s.title; d_text.textContent=s.text;
  const esc=v=>v.replace(/&/g,"&amp;").replace(/</g,"&lt;");
  d_tools.innerHTML="<b>Picked up:</b> "+esc(s.tools);
  d_learn.innerHTML="<b>What I took away:</b> "+esc(s.learn);
}
const d_when=document.getElementById("d-when"),d_kind=document.getElementById("d-kind"),d_title=document.getElementById("d-title"),
      d_text=document.getElementById("d-text"),d_learn=document.getElementById("d-learn"),d_tools=document.getElementById("d-tools");
document.getElementById("prev").onclick=()=>show(cur-1);
document.getElementById("next").onclick=()=>show(cur+1);

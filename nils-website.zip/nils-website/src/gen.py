import json, html, re

T = open('template.html', encoding='utf-8').read()
code = json.load(open('../data/code_all.json'))

def esc(s): return html.escape(s, quote=False)

def hl(src):
    out = []
    for line in esc(src.replace('\t', '    ')).split('\n'):
        m = re.match(r'^(\s*)(#.*|--.*)$', line)
        if m:
            out.append(f'{m.group(1)}<span class="c">{m.group(2)}</span>')
        else:
            m2 = re.match(r'^(.*?\S.*?)(\s+#\s.*)$', line)
            out.append(f'{m2.group(1)}<span class="c">{m2.group(2)}</span>' if m2 else line)
    return '\n'.join(out)

def codebox(key, label, fname):
    n = len(code[key].strip().split('\n'))
    return f'''<details class="code"><summary><span>View the code</span><small>{label}, {n} lines</small></summary>
<div class="codebar"><span>{fname}</span><button class="ccopy" type="button" data-copyfrom="code-{key}">Copy code</button></div>
<pre><code id="code-{key}">{hl(code[key].strip())}</code></pre></details>'''

def fig(key, alt, cap):
    return f'<figure><img loading="lazy" src="__IMG_{key}__" alt="{alt}"><figcaption>{cap}</figcaption></figure>'

def card(tags, title, meta, one, tools, lead, q, did, res, extra='', figs='', codeh='', did_label='What I did'):
    t = ''.join(f'<span>{x}</span>' for x in tools)
    return f'''
      <article class="proj" data-tags="{tags}">
        <button type="button" aria-expanded="false">
          <div>
            <h2>{title}</h2>
            <p class="meta">{meta}</p>
            <p class="one">{one}</p>
            <div class="tools">{t}</div>
          </div>
          <span class="plus" aria-hidden="true">+</span>
        </button>
        <div class="more" hidden>
          <p class="lead">{lead}</p>
          <div class="cols">
            <div><h3>The question</h3><p>{q}</p></div>
            <div><h3>{did_label}</h3><p>{did}</p></div>
            <div><h3>The result</h3><p>{res}</p></div>
          </div>
          {extra}
          {('<div class="gallery">' + figs + '</div>') if figs else ''}
          {codeh}
        </div>
      </article>'''

cards = []

# 1 SQL $95M
cards.append(card('finance data',
  'More return with less risk for a $95M portfolio?',
  'Portfolio return and risk analysis in SQL, Master in Management, Hult 2026',
  'A high-net-worth client held about $95M in five ETFs. I analyzed the whole portfolio inside a MySQL database and proposed a rebalancing that raises return and lowers risk at the same time.',
  ['MySQL', 'Stored procedures', 'Portfolio risk', 'Rebalancing'],
  'The setup: a high-net-worth client with roughly $95 million spread across five ETFs wants to know whether the portfolio is still built the right way. The constraint for this assignment was that every number had to come out of the database itself, with no spreadsheet in between.',
  'How have IXN (global technology), QQQ (Nasdaq-100), IEF (7 to 10 year Treasuries), VNQ (US real estate) and GLD (gold) performed over 12, 18 and 24 months, how much risk does each position add, and what should the client sell or buy?',
  'I loaded three years of daily prices into MySQL and wrote stored procedures that calculate the return over each window, the monthly variance and the annualized sigma, so every figure can be rerun with a single call. Looking at the holdings side by side showed that IXN and QQQ largely own the same large tech names, so the client was paying twice for one bet. I then passed new weights into the same procedures to compare the current and the proposed portfolio on identical terms.',
  'Sell 10% of IEF and 5% of QQQ and move that 15% into DBC, a broad commodity ETF that behaves differently from both tech stocks and bonds. On 12-month data, the expected portfolio return rises from 38.74% to 43.19% while annualized sigma falls from 12.25% to 11.77%. More return for less risk is rare, and it came from removing an overlap rather than taking a bigger bet.',
  figs=fig('sql', 'SQL stored procedure that calculates annualized portfolio sigma with the new weights', 'One of the stored procedures: annualized sigma of the portfolio with the proposed weights.')))

# 2 NE Revolution
ne_extra = '''
          <div class="deep">
            <div>
              <h3>What we found before we touched the World Cup</h3>
              <p>We started with what fans actually say. Running NLP on 412 fan documents (app store reviews, ticketing feedback, social posts and forum threads from 2025 and 2026), we saw that interest was not the problem. 54.7% of fan conversation was about digital friction, sentiment about Ticketmaster was 77.8% negative, and 50.6% of app users showed signs of churn. Only 0.2% of the documents connected the club to the World Cup at all. Our headline for the client: the problem is the pipeline, not the product.</p>
            </div>
            <ul class="figs4" aria-label="Key findings from the fan analysis">
              <li><b>54.7%</b><span>of fan conversation is about digital friction</span></li>
              <li><b>77.8%</b><span>of Ticketmaster sentiment is negative</span></li>
              <li><b>50.6%</b><span>of app users show churn signals</span></li>
              <li><b>0.2%</b><span>of fan documents mention the World Cup</span></li>
            </ul>
            <div>
              <h3>Who we went after</h3>
              <p>Instead of “everyone who watches a World Cup game”, we sized three segments that are already in Boston and already care about soccer: the Hispanic community (about 131,000 people in Boston, 44% of whom follow World Cup 2026), international students (about 84,000 in Massachusetts) and young adults aged 18 to 39 (about 354,000). Each one gets its own way in.</p>
            </div>
            <div>
              <h3>The plan: four pillars</h3>
              <ol class="pillars">
                <li><b>Fix the pipeline.</b> Remove forced account creation, take the friction out of ticketing and get to a one-tap ticket purchase. Without this, every other idea leaks.</li>
                <li><b>Activate the three segments</b> with a mix of physical and digital capture, so no paid media is needed to get the first contact.</li>
                <li><b>Convert with a Rev-Pass.</b> A $25 a month student bundle with public transit included, a semester commitment and sign-up only through the app.</li>
                <li><b>Open the B2B channel.</b> Group deals for hospitals, pharma companies, universities and student governments around Boston.</li>
              </ol>
            </div>
            <div>
              <h3>How it works on the ground</h3>
              <p>The club app is the conversion goal because it is the only channel the club owns: first-party data, push notifications and a direct path to a ticket. To get people into it, we proposed QR wristbands at the FIFA Fan Zone on City Hall Plaza (16 days) and campus pop-ups: one scan means an app download and an entry into a raffle for a VIP match experience. Visitors who opt in can be reached again two to three days later with Revolution ads on Instagram and TikTok through location-based retargeting. During the tournament, a weekly World Cup prediction game keeps them opening the app, with points that turn into ticket discounts. Within 48 hours of the final, a “Your first match for $5” push turns the emotional high into a first visit, and a referral link lets every new fan bring friends. The goal in one sentence: a student who downloads the app in June 2026 is a season ticket holder by 2027.</p>
            </div>
            <div>
              <h3>Tools we used</h3>
              <p>Minto pyramid and SCQA to build the storyline, an issue tree to split the problem, NLP sentiment analysis, segment sizing from public data, Porter’s five forces, SWOT and Ansoff, a 2×2 prioritization of tactics and a four-phase roadmap up to 2030. To show the idea is buildable, we also prototyped a World Cup Hub as a small working web app.</p>
            </div>
          </div>'''
cards.append(card('strategy data',
  'How do you turn three weeks of World Cup into ten years of fans?',
  'Client consulting project for the New England Revolution (Major League Soccer), student consulting team, Hult, May 2026',
  'In summer 2026 the World Cup comes to Gillette Stadium, the Revolution’s own home. Our team built a data-driven strategy to turn World Cup visitors in Boston into long-term Revolution fans, from fan sentiment analysis to a concrete app funnel.',
  ['Consulting', 'NLP sentiment analysis', 'Segmentation', 'Go-to-market', 'Sports business'],
  'This was a real client project. The Revolution’s question sounds simple: Boston hosts World Cup matches at the club’s own stadium, and hundreds of thousands of soccer fans will be in town. How does a Major League Soccer club make sure that excitement doesn’t leave with them? Our final deck had 31 slides and covered everything from the diagnosis to a roadmap.',
  'Where does the club lose fans today, which groups in Boston are most likely to stick, and what has to happen in June and July 2026 so that a World Cup visitor ends up with a Revolution ticket?',
  'We analyzed fan feedback with NLP, sized the most promising audiences, and designed a capture-and-convert funnel around the club app, with concrete tactics, timing and a prototype. Details below.',
  'A four-pillar strategy: fix the digital ticket funnel first, capture three target segments at the Fan Zone and on campuses, convert them with a student Rev-Pass and a $5 first match, and add a B2B channel for companies and universities.',
  extra=ne_extra,
  figs=fig('ne1', 'Slide: The problem is the pipeline, with NLP findings and the four-pillar response', 'Diagnosis: what the fan data says, and our four-pillar answer.')
      + fig('ne2', 'Slide: why the app is the target channel', 'Why the club app is the conversion goal.')
      + fig('ne3', 'Slide: fan zone wristband capture and location-based follow-up', 'Capture: QR wristbands at the Fan Zone plus opt-in follow-up on social media.')
      + fig('ne4', 'Slide: prediction game, five-dollar first match and referral system', 'Keep and convert: prediction game, $5 first match and referrals.')
      + fig('ne', 'Poster for the New England Revolution app concept with a World Cup ticket raffle', 'Our app poster for the raffle at the Fan Zone.'),
  did_label='What we did'))

# 3 Semester at Sea
cards.append(card('data finance',
  'What does the board need to know about unpaid tuition?',
  'Power BI executive briefing, individual final assessment, Business Intelligence, Hult 2026',
  'For a study-abroad program’s board meeting, I turned raw booking, invoice and payment data into a one-page Power BI briefing on revenue, collections and risk.',
  ['Power BI', 'DAX', 'Data modeling', 'Revenue recognition', 'Executive reporting'],
  'Semester at Sea runs university voyages around the world, and students pay their tuition in installments. Ahead of a board meeting, leadership wanted one page that answers where the money stands. I worked from the raw tables for bookings, invoices and payments, and the page had to be readable in two minutes by people who will never open Power BI themselves.',
  'How much revenue has been invoiced and recognized, how much is still outstanding, which students and voyage terms drive revenue, and where does the payment process create risk?',
  'I built the data model in Power BI and wrote DAX measures for invoiced, collected and outstanding revenue. Revenue is recognized by voyage term, so it shows up in the period the voyage actually happens, and a waterfall walks from contracted revenue down to what is still open. While building it I documented the data quality issues I ran into, for example installments without a due date, which make it impossible to say what is actually overdue.',
  '$37.46M invoiced, an 84.8% collection rate and $5.70M still outstanding. Students who sail more than one term bring in 3.6 times the revenue per person, so I recommended a loyalty offer for returning students and automatic payment reminders, and I listed the missing due dates as the first data fix before the next board cycle.',
  figs=fig('sas', 'Power BI dashboard with revenue, collections and risk indicators', 'The one-page board briefing in Power BI.')))

# 4 11teamsports cost / scenario
scn = '''
          <div class="scn" data-scn>
            <div class="scn-head">
              <h3>Try the scenario switch from my model</h3>
              <p>Same revenue drop, very different outcome. Pick a scenario for FY2027.</p>
            </div>
            <div class="scn-btns" role="group" aria-label="Scenario">
              <button type="button" data-i="0" aria-pressed="true">Base case</button>
              <button type="button" data-i="1" aria-pressed="false">Volume −20%</button>
              <button type="button" data-i="2" aria-pressed="false">Price −20%</button>
              <button type="button" data-i="3" aria-pressed="false">Volume +10%</button>
            </div>
            <dl class="scn-nums">
              <div><dt>Net revenue</dt><dd data-k="rev"></dd></div>
              <div><dt>Contribution margin</dt><dd data-k="cm"></dd></div>
              <div><dt>CM ratio</dt><dd data-k="cmr"></dd></div>
              <div><dt>Operating income</dt><dd data-k="oi"></dd></div>
            </dl>
            <div class="scn-bars" aria-hidden="true"></div>
            <p class="scn-note" aria-live="polite"></p>
          </div>'''
cards.append(card('finance',
  'Why a 20% price cut hurts more than losing 20% of sales',
  'Cost and managerial analysis with a full Excel financial model, Master of Finance, Hult 2026',
  'I modeled the business I worked in at 11teamsports like a CFO would: cost structure, break-even, price floor, a three-year investment case and a scenario switch. The answer to “what if sales drop?” depends entirely on how they drop.',
  ['Excel financial model', 'CVP analysis', 'Break-even', 'NPV', 'Scenario planning', 'Budgeting'],
  'For this assignment I picked a business I know from the inside: the marketplace resale unit at 11teamsports, where I worked in 2025. It sells leftover teamwear, boots and training wear on Amazon, Zalando and About You. I built a ten-sheet Excel model, from assumptions and cost structure to a monthly budget, for a FY2027 plan of €4.75M in net revenue.',
  'How resilient is the unit if sales fall, how far can it discount before a sale stops making sense, and is a €18,000 AI tool that automates listings, category mapping and price syncing worth the money?',
  'I separated variable from fixed costs, using the high-low method to split the warehouse as a mixed cost, and treated the book value of the overstock as sunk. That changes the picture: 95.8% of costs are variable, so the unit covers its annual fixed costs after about 75 sales days. From there I calculated a weighted contribution margin across jerseys, boots and training wear, a price floor per product line, a stress test for higher return rates and a three-year NPV for the automation tool.',
  'Break-even sits at about 33,000 units, with a 79% margin of safety. The tool saves half a full-time role and has an NPV of about €10,500 at a 13.8% discount rate, so I recommended buying it. The most useful finding came from the scenarios: losing 20% of volume cuts operating income by a quarter, but the same revenue drop through deeper discounts wipes out almost the entire margin and pushes the unit into a loss. The rule for the team: protect the price floor.',
  extra=scn,
  figs=fig('cost', 'Chart of cumulative contribution margin rising above annual fixed costs in spring', 'Cumulative contribution margin passes the year’s fixed costs in early spring.')
      + fig('costtab', 'Table splitting annual costs into variable, fixed, direct, indirect, relevant and sunk', 'Cost structure: almost everything is variable, and 44% is sunk.')))

# 5 Fisher SQL
fisher_tbl = '''
          <div class="tblwrap">
            <table class="tbl">
              <caption>Current portfolio vs. my optimized allocation (monthly figures, rf = 4.5% p.a.)</caption>
              <thead><tr><th scope="col"></th><th scope="col">Current</th><th scope="col">Optimized</th></tr></thead>
              <tbody>
                <tr><th scope="row">Expected monthly return</th><td>2.47%</td><td><b>2.98%</b></td></tr>
                <tr><th scope="row">Monthly risk (weighted σ)</th><td>8.04%</td><td>8.75%</td></tr>
                <tr><th scope="row">Sharpe ratio</th><td>0.26</td><td><b>0.30</b></td></tr>
                <tr><th scope="row">Beta vs. S&amp;P 500 (VOO)</th><td>1.17</td><td>1.21</td></tr>
                <tr><th scope="row">Weights</th><td>NVDA 21%, AAPL 20%, IEF 16%, GOOGL 16%, MSFT 12%, AMZN 10%, JPM 6%</td><td>GOOGL 23%, NVDA 21%, JPM 18%, AAPL 9%, AMZN 9%, IEF 9%, NEM 7%, MSFT 4%</td></tr>
              </tbody>
            </table>
          </div>'''
cards.append(card('finance data',
  'Can an $85 billion equity book earn more per unit of risk?',
  'Portfolio analytics in SQL for a Fisher Investments style client, Master in Management, Hult 2026',
  'I built a small investment database from scratch and used it to measure return, risk, Sharpe ratio and beta for a large-cap portfolio, then tested one change that lifts the risk-adjusted return.',
  ['MySQL', 'Window functions', 'Sharpe ratio', 'Beta', 'Portfolio optimization'],
  'The client in this project is modeled on Ken Fisher: three accounts holding Apple, Alphabet, Amazon, Microsoft, Nvidia, JPMorgan and the IEF Treasury ETF, worth about $85 billion at the latest prices. I set up the database myself, with customer, account, holdings and security tables plus three years of daily prices (June 2023 to June 2026) for every ticker and for VOO as the S&amp;P 500 benchmark.',
  'How much return does each position deliver for the risk it adds, how sensitive is the whole portfolio to the market, and is there one change that improves the risk-adjusted return?',
  'I calculated daily returns with window functions (LAG over each ticker), scaled them to monthly return and risk, and ranked every holding by its Sharpe ratio with a 4.5% risk-free rate. Beta against VOO comes straight from covariance and variance in SQL. Then I tested adding Newmont (NEM), a gold miner with a below-market beta, stored the new allocation in its own table and compared the current and the optimized portfolio in one query.',
  'Nvidia, JPMorgan and Alphabet earn the most per unit of risk, while Microsoft and the Treasury ETF barely beat, or fall short of, the risk-free rate in this period. Shifting weight toward Alphabet, JPMorgan and Nvidia, trimming Apple and Microsoft and adding 7% Newmont lifts the expected monthly return from 2.47% to 2.98% and the Sharpe ratio from 0.26 to 0.30. The trade-off is a slightly higher beta, 1.17 to 1.21, which is a decision the client has to make consciously.',
  extra=fisher_tbl,
  codeh=codebox('fisher', 'SQL', 'Fisher Investments Analysis.sql')))

# 6 ML
ml_tbl = '''
          <div class="tblwrap">
            <table class="tbl">
              <caption>Test set results for the four models</caption>
              <thead><tr><th scope="col">Model</th><th scope="col">Precision</th><th scope="col">Recall</th><th scope="col">F1</th><th scope="col">ROC-AUC</th></tr></thead>
              <tbody>
                <tr><th scope="row">Logistic regression (baseline)</th><td>0.60</td><td>0.14</td><td>0.23</td><td>0.88</td></tr>
                <tr class="pick"><th scope="row">Decision tree, max depth 10 (recommended)</th><td>0.79</td><td>0.77</td><td>0.78</td><td>0.90</td></tr>
                <tr><th scope="row">Random forest, tuned, class-weighted</th><td>0.59</td><td>0.77</td><td>0.66</td><td>0.97</td></tr>
                <tr><th scope="row">XGBoost, weighted for the rare class</th><td>0.71</td><td>0.77</td><td>0.73</td><td>0.98</td></tr>
              </tbody>
            </table>
          </div>'''
cards.append(card('data',
  'Which machine is going to fail next?',
  'Predictive maintenance with machine learning, Master in Management, Hult 2026',
  'Sensor data from 10,000 machines, of which only 3.39% fail. I built and compared four classification models and picked the one a maintenance team can actually trust and understand.',
  ['Python', 'scikit-learn', 'XGBoost', 'Imbalanced data', 'Model evaluation'],
  'An industrial dataset with sensor readings for 10,000 machines: air and process temperature, rotational speed, torque and tool wear. Only 339 of them failed. That is exactly what makes the problem hard: a model that always says “no failure” is already 96.6% accurate and completely useless.',
  'Can we predict which machine fails next early enough for maintenance to step in, and which signals give a failure away?',
  'I split the data with stratification so training and test sets keep the same 3.39% failure rate, then trained four models: a scaled logistic regression as the baseline, a decision tree tuned over depths 1 to 15, a random forest tuned with grid search and class weights, and XGBoost with extra weight on the rare class. I judged them on precision, recall, F1 and ROC-AUC instead of accuracy, because a missed failure and a technician sent out for nothing have very different costs.',
  'The tuned decision tree (max depth 10) gave the best balance: it catches 77% of all failures and 79% of its alarms are real, compared with 14% recall for the baseline. XGBoost and the random forest rank machines slightly better overall, but raise more false alarms. I recommended the tree, because a maintenance team can follow every rule it uses, with torque, tool wear and rotational speed as the strongest signals.',
  extra=ml_tbl,
  figs=fig('ml', 'Bar chart comparing precision, recall, F1 and ROC-AUC across four models', 'All four models on the metrics that matter for rare failures.')
      + fig('mldepth', 'Line chart of decision tree performance by maximum depth', 'Tuning the decision tree: performance by tree depth.'),
  codeh=codebox('ml', 'Python, Jupyter notebook', 'predictive_maintenance.ipynb (modeling part)')))

# 7 Sales dashboard
cards.append(card('data',
  'Who is our best country manager, and should we stop selling books?',
  'Power BI sales dashboard and management memo, team of two, Business Intelligence, Hult 2026',
  'About $1.1 billion in global sales from 2017 to 2019. Together with a classmate I built a multi-page Power BI report to answer two decisions management actually had to make.',
  ['Power BI', 'DAX', 'Data visualization', 'Management memo'],
  'A retailer sells books, computers, home and kitchen products, mobile devices and video games across Asia, Europe, Latin America, North America and Oceania. Management asked two direct questions, and we answered them with a Power BI report and a short memo.',
  'Which country manager really performs best, and does it make sense to discontinue the book line?',
  'We built pages for revenue trends by product line, a sales map by country, manager cards and two decision pages. For the managers we looked beyond total revenue to revenue per sale and a performance ratio, and added GNI per capita as economic context for each country. For books we compared the three-year CAGR of every product line and region.',
  'Emma Smith (USA) leads with $211.9M in revenue and is also among the most efficient per sale. Australia grew fastest, by 37% from 2017 to 2018, while wealthy markets like Belgium and France are stagnating. Books fell 28% over three years while home and kitchen, video games and mobile each grew more than 20%, but the decline is much milder in Oceania and Latin America. Our advice: don’t cut books yet. First bring product margins, inventory costs and cross-selling data into the pipeline, because revenue alone can’t answer that question.',
  figs=fig('sales1', 'Power BI page comparing country managers by revenue, growth and performance ratio', 'Decision page 1: who is our best country manager?')
      + fig('sales2', 'Power BI page showing book revenue trends and CAGR by product line', 'Decision page 2: should we discontinue books?'),
  did_label='What we did'))

# 8 Bike
cards.append(card('data',
  'Why do people rent bikes in winter?',
  'Python analysis project, Master in Management, Hult 2026',
  '1,096 hourly rental records from October to December 2023, combined with weather data, to find out who still rides when it gets cold and what really drives demand.',
  ['Python', 'pandas', 'seaborn', 'Correlation analysis', 'Data storytelling'],
  'A bike-sharing service shared one quarter of hourly rental data, with temperature, humidity, wind, solar radiation and rain for every hour. Rentals drop in late autumn, and the business wanted to know who its remaining customers are so it can serve them better.',
  'What motivates most customers to rent a bike in late autumn and winter, and how much does the weather really matter?',
  'I cleaned and typed the data in pandas, turned the holiday and functioning-day flags into numbers and extracted hour, month and weekday from the timestamp. Then I ran a Pearson correlation of rentals against every variable, drew a heatmap, plotted average demand by hour of day and fitted regression plots for the two strongest weather drivers, temperature and solar radiation.',
  'Demand peaks around 8am and 6pm on working days, so the typical winter customer is a commuter, not a leisure rider. Warmer and sunnier hours do lift rentals, but the time of day explains more than the weather. My recommendations were built around commuters, such as making sure bikes are available at stations during rush hour.',
  figs=fig('bike', 'Line chart of average bike rentals by hour of day with peaks around 8am and 6pm', 'Average rentals by hour: two clear commuter peaks.')
      + fig('bikeheat', 'Correlation heatmap between rentals and weather and time variables', 'Correlation heatmap of rentals against weather and time.'),
  codeh=codebox('bike', 'Python', 'bike_rentals_analysis.py')))

projects = '''<!-- ================= PROJECTS ================= -->
<div id="projects" role="tabpanel" aria-labelledby="tab-projects" hidden>
  <section class="proj-head">
    <div class="wrap">
      <h1>Things I’ve built</h1>
      <p class="lede">Eight projects from my two master’s programs, from a real client engagement to SQL portfolio analytics and machine learning. Open one to see the question behind it, how I approached it, what came out, and where available the slides, dashboards and code.</p>
      <div class="filters" role="group" aria-label="Filter projects">
        <button class="chip" type="button" data-f="all" aria-pressed="true">All</button>
        <button class="chip" type="button" data-f="finance" aria-pressed="false">Finance</button>
        <button class="chip" type="button" data-f="data" aria-pressed="false">Data &amp; SQL</button>
        <button class="chip" type="button" data-f="strategy" aria-pressed="false">Strategy</button>
      </div>
    </div>
  </section>
  <section class="plist">
    <div class="wrap" id="plist">''' + ''.join(cards) + '''
    </div>
  </section>
</div>
'''

# ---------- certificates ----------
def crow(title, issuer, date, img=None, verify=None, note=None):
    th = f'<span class="thumb"><img loading="lazy" src="__IMG_{img}__" alt="Certificate: {title}"></span>' if img else '<span class="thumb none" aria-hidden="true"></span>'
    v = f'<a class="verify" href="{verify}" target="_blank" rel="noopener">Verify on Coursera</a>' if verify else ''
    n = f'<p class="cnote">{note}</p>' if note else ''
    d = f'<span class="cdate">{date}</span>' if date else ''
    return f'<li class="cert">{th}<div class="ctext"><h3>{title}</h3><p class="iss">{issuer}</p>{n}{v}</div>{d}</li>'

groups = [
 ('Degrees', [
   crow('Master of Science in Management (Business Analytics)', 'Hult International Business School, Boston. STEM-designated, GPA 3.42', 'Aug 2026', 'c_mim'),
   crow('Master of Finance', 'Hult International Business School, Boston', 'Until Apr 2027'),
   crow('B.A. Business Administration, Marketing Management', 'SRH University Heidelberg. Final grade 2.0 (German scale), thesis 1.4', 'Nov 2024', note='Transcript of records available on request.'),
 ]),
 ('Data and programming', [
   crow('Introduction to Statistics in Python', 'DataCamp, 4 hours', 'Sep 2026', 'c_statpy'),
   crow('Intermediate SQL', 'DataCamp, 4 hours', 'Jun 2026', 'c_isql'),
   crow('Introduction to SQL', 'DataCamp, 2 hours', 'May 2026', 'c_sql'),
   crow('Intermediate Python', 'DataCamp, 4 hours', 'May 2026', 'c_ipy'),
   crow('Introduction to Python', 'DataCamp, 4 hours', 'May 2026', 'c_py'),
   crow('DAX Functions in Power BI', 'DataCamp, 3 hours', 'Mar 2026', 'c_dax'),
   crow('Introduction to Statistics in Google Sheets', 'DataCamp, 4 hours', 'Nov 2025', 'c_gsheets'),
 ]),
 ('AI', [
   crow('AI Fundamentals', 'Google, via Coursera', 'Jul 2026', 'c_gai', 'https://coursera.org/verify/4XI8W8936U4L'),
   crow('THRIVE with AI: Mastering AI for Leadership, Growth &amp; Innovation', 'Hult International Business School, via Coursera', 'Jul 2026', 'c_thrive', 'https://coursera.org/verify/PF1N1H2Z1DPV'),
   crow('AI Fluency for Students', 'Anthropic', '', 'c_aif'),
   crow('Claude 101', 'Anthropic', '', 'c_c101'),
 ]),
 ('Business and communication', [
   crow('Certified Conflict and Negotiation Manager', 'SRH Fernhochschule with SPIEGEL Akademie, 150 hours', 'Aug 2026', 'c_srhneg'),
   crow('Content, Advertising &amp; Social IMC', 'Northwestern University (Medill), via Coursera', 'Sep 2025', 'c_imc', 'https://coursera.org/verify/WJAI3YP7S084'),
 ]),
 ('Work references', [
   crow('Roche Diagnostics, Marketing Point of Care', 'Six-month internship in Mannheim', 'Oct 2023 – Apr 2024', note='Top rating in the reference letter (translated from German): his work “found our fullest recognition at all times and in every respect”, with “excellent solutions” to every problem.'),
   crow('11teamsports, Customer Operations and Marketplace', 'Five-month internship in Satteldorf', 'Mar – Aug 2025', note='Top rating (translated from German): results “always outstanding in quality and quantity”, all tasks completed “to our fullest satisfaction”.'),
   crow('SAP Deutschland, Marketing Germany', 'School internship in Walldorf', 'Jun 2019', note='Event preparation and presentations for the marketing team.'),
 ]),
]
ncourses = sum(len(g[1]) for g in groups[1:4])
cert_html = f'''
<!-- ================= CERTIFICATES ================= -->
<div id="certificates" role="tabpanel" aria-labelledby="tab-certificates" hidden>
  <section class="proj-head">
    <div class="wrap">
      <h1>Certificates and references</h1>
      <p class="lede">My degrees, the {ncourses} courses I finished on the side, and what my internship supervisors wrote about me. Click a certificate to open it. The Coursera ones can be verified online. Reference letters are in German and I’m happy to send them.</p>
    </div>
  </section>
  <section class="clist">
    <div class="wrap">''' + ''.join(
  f'''
      <section class="cgroup">
        <div class="cg-head"><h2>{name}</h2><span class="count">{len(rows)}</span></div>
        <ul>{''.join(rows)}</ul>
      </section>''' for name, rows in groups) + '''
    </div>
  </section>
</div>
'''

a = T.index('<!-- ================= PROJECTS ================= -->')
b = T.index('<!-- ================= CONTACT ================= -->')
T = T[:a] + projects + cert_html + '\n' + T[b:]

T = T.replace('<a class="tab" role="tab" href="#projects" id="tab-projects" aria-controls="projects">Projects</a>',
  '<a class="tab" role="tab" href="#projects" id="tab-projects" aria-controls="projects">Projects</a>\n      <a class="tab" role="tab" href="#certificates" id="tab-certificates" aria-controls="certificates">Certificates</a>')
T = T.replace('const panels=["about","path","projects"];', 'const panels=["about","path","projects","certificates"];')

css = open('extra.css').read()
T = T.replace('/* CONTACT (all tabs) */', css + '\n/* CONTACT (all tabs) */')
js = open('extra.js').read()
T = T.replace('/* ---------- image zoom ---------- */\ndocument.querySelectorAll(".proj figure img").forEach(img=>{',
              js + '\n/* ---------- image zoom ---------- */\ndocument.querySelectorAll(".proj figure img, .cert .thumb img").forEach(img=>{')
assert 'scnData' in T and 'tab-certificates' in T
open('template2.html', 'w', encoding='utf-8').write(T)
print('ok', len(T))
